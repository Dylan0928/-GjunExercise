package com.example;

public class Fish extends Animal {

    public Fish() {
        super(0);
    }

}
