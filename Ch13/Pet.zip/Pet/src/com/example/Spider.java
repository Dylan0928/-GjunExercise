package com.example;

public class Spider extends Animal {
    
    public Spider() {
        super(8);
    }
    
}

