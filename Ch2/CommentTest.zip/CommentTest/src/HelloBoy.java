public class HelloBoy {

    public static void main(String[] args) {
        Boy boy = new Boy();
        boy.greet("多拉A夢");
    }
    
}
