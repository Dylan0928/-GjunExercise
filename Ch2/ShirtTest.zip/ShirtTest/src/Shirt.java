public class Shirt {

	public void displayShirtInformation(){


	}
}
