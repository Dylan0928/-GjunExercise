package com.example;

import java.util.*;

public class LambdaCollectionTest {

    public static void main(String[] args) {
        List<Person> personList = Person.createList();
        
        // 使用 Lambda Expression 定義以LastName來升冪排序           
    
        // 使用 Lambda Expression 定義以Age來降冪排序         
        
        // 使用 Lambda Expression 定義移除所有女性成員        
        
        // 使用 Lambda Expression 定義移除年齡小於35成員        
        
    }
    
}

