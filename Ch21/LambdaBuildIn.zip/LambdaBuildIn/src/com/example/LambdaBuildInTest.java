package com.example;

import java.util.List;
import java.util.function.*;

public class LambdaBuildInTest {

    public static void main(String[] args) {
        List<Person> personList = Person.createList();
        
        // 使用 Lambda Expression 定義以Function 函式介面,傳回稱謂(姓名前加上Ms./Mr.)

        
        
        
        
        // 使用 Lambda Expression 定義Predicate 函式介面,篩選列印30歲以下的Person資訊

        
        
        
        // 使用 Lambda Expression 定義以Comsumer 函式介面以FirstName(age)格式來列印Person資訊           

        
        
        
        
        
    }
    
}
