package com.example;

public enum Gender { MALE, FEMALE }

