package com.example;

import java.util.*;
import java.util.function.Supplier;

public class MethodReferenceTest {

    public static void main(String[] args) {
        List<Person> personList = Person.createList();
        
        //使用方法參照列印所有成員的全名
        
        
        
        //使用 Lambda Expression 定義 Suppier 函式介面, 新增成員
        
        
        
        
        //使用方法參照將成員以原生排序規則排序並列印
        
        
        
        
        //使用方法參照將成員以年紀反向排序並列印
        
        
        
    }
    
}
