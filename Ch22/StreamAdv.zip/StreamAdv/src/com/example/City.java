package com.example;

public enum City {
    Taipei, Tainan, Kaohsiung
}
