package com.example;

import java.util.*;

public class StreamAdvTest {

    public static void main(String[] args) {
        List<Person> people = new ArrayList<>();
        // 使用Builder建立Person物件
        

        // 使用迴圈計算所有人的年紀總和
        
        
        // 使用串流計算台北成員的年紀總和
        
        
        // 使用parallelStream並行串流計算台南成員的年紀總和
        
        
        // 串流使用parallel()並行計算高雄成員的年紀總和
        
        
        // 使用reduce(accumulator)計算男性成員的年紀總和
        
        
        // 使用reduce(identity, accumulator)計算女性成員的年紀總和
        
    }
    
}

