public class VacationScale {
    public int yearOfService;
    
    public void displayVacationDays(){
              
        
    }    
    
}
