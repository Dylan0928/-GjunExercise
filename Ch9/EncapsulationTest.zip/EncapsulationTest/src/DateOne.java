public class DateOne {
    public int day;
    public int month;
    public int year;
}
